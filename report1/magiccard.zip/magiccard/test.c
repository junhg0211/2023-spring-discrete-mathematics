int main(void)
{
    int numbers[2096096];

    return 0;
}
